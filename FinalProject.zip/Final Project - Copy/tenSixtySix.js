function normanInvasion() {
  window.location = "willyTheConq.html";
}
function haroldGodwinson() {
  history.back();
}
function siteNotComplete() {
  document.getElementById("siteNotFinished").innerHTML = "Check back in a bit!";
}
